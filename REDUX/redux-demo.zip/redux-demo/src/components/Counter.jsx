import React, { Component } from "react"

export default class Counter extends Component {
	constructor(props) {
		super(props)
		this.state = {
			count: 0
		}
	}

	increment = event => {
		this.setState(prevstate =>
			// state might change due to some other function elsewhere in the application, therefore the below will not work
			// count: this.state.count + 1
			// to counter this, we pass in the state in the this.setState function to freeze the state at that point in time (we are working with a snapshot of the stae at a point in time)
			({
				count: prevstate.count + 1
			})
		)
	}

	decrement = event => {
		this.setState(prevstate => ({ count: prevstate.count - 1 }))
	}

	render() {
		return (
			<div>
				<h2>Counter</h2>
				<div>
					<button onClick={this.decrement}>-</button>
					<span>{this.state.counter}</span>
					<button onClick={this.increment}>+ </button>
				</div>
			</div>
		)
	}
}
