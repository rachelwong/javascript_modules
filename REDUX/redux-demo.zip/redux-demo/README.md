## Redux Counter App

Classnotes

- do the render first, what state and props are required
- if you're not rendering, you won't need states, props
